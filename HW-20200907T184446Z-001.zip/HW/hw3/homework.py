# ----------------------------------------------------------------------
# Name:        homework3
# Purpose:     Practice Manipulating Sequence Data Types
#
# Author(s): Lovepreet Dhillon and Mark Mathew
# ----------------------------------------------------------------------
"""
Implement various functions to practice manipulating sequence data types

Q1: transpose
Q2: grader
Q3: has_duplicates
Q4: remove_vowels
Q5: same_word_count
"""

# Enter your 5 function definitions here

def transpose(matrix):
    """
    Q1 Transposes valid matrices
    :param matrix: matrix to transpose
    :return: (list) transposed matrix
    """
    transposed_matrix = [[matrix[y][x] for y in range(len(matrix))] for x in
                         range(
            len(matrix[0]))]
    return transposed_matrix

def grader(grades,threshold = 4):
    """
    Q2 returns the average of all grades within the threshold
    :param grades: list of student's grades
    :param threshold: number of grades, defaults to 4
    :return: (number) average of qualified grades
    """
    if len(grades) == 0:
        return 0
    else:
        while len(grades) > threshold:
            grades.remove(min(grades))
        return sum(grades)/len(grades)

def has_duplicates(x):
    """
    Q3 Checks when elements appear more than once in a given sequence
    :param x: string to check
    :return: (Boolean) True if contains dupes
    """
    return len(set(x)) < len(x)

def remove_vowels(sentence):
    """
    Q4 Purpose is to remove vowels from a string
    :param sentence: input sentence
    :return: (string) without vowels
    """
    vowels = 'a,e,i,o,u,A,E,I,O,U'
    return ''.join([ x for x in sentence if x not in vowels])


# Problem 5
def same_word_count(phrase_one,phrase_two):
    """
    Q5 Checks if two phrases are equal in word length
    :param phrase_one: first phrase to compare to
    :param phrase_two: second phrase to compare
    :return: (Boolean) True if they are equal in length
    """
    return len(phrase_one.strip().split())==len(phrase_two.strip().split())


def main():
    m = [[1, 2, 3],
         [4, 5, 6],
         [7, 8, 9],
         [0, 2, 4]]
    print(len(m))
    print(transpose(m))

    anna = [100, 90, 60]
    print(grader(threshold=2, grades=anna))  # 95.0
    print(anna)  # [100, 90]

    ryan = [80, 90, 81, 100, 100, 60, 70]
    print(grader(ryan, 7))  # 83.0
    print(ryan)  # [80, 90, 81, 100, 100, 60, 70]

    alex = [100, 80, 60, 80]
    print(grader(alex))  # 80.0
    print(alex)  # [100, 80, 60, 80]

    zoe = [100, 80, 60, 84, 94]
    print(grader(zoe))  # 89.5
    print(zoe)  # [100, 80, 84, 94]

    t = ("hello")
    print(has_duplicates(t))
    t = ('python')
    print(has_duplicates(t))
    t = (1, 4, 2, 4)
    print(has_duplicates(t))
    t = ([])
    print(has_duplicates(t))

    print(remove_vowels('Anticipation'))  # ntcptn
    print(remove_vowels('PYTHON'))  # PYTHN
    print(remove_vowels('Hello World!'))  # Hll Wrld!

    print(same_word_count('Hello World!', 'Hi               there'))  # True
    print(same_word_count('Hello  World!', 'Python is fun'))  # False

if __name__ == '__main__':
    main()
