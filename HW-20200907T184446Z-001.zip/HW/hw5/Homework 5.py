# ----------------------------------------------------------------------
# Name:    homework5
# Purpose: Practice working with Python functions and files
#
# Author(s): Lovepreet Dhillon and Mark Mathews
# ----------------------------------------------------------------------
"""
Implement various functions

Q1: top_midterm
Q2: longest_sequence
Q3: encrypt decorator
Q4: learn
Q5: babble
"""
import string
import random

# Enter your 5 function definitions here
# Include the statement below at the top of the babble definition
# random.seed(100)

def top_midterm(dictionary, midterm_grades = lambda dictionary: [grades[2] for
                                                            grades
                                                        in dictionary.values()]):
    """
    returns the name of the highest scorer
    :param dictionary: input dictionary
    :param size: size of a given dictionary
    :return: (string) name of highest scoring student
    """
    if dictionary == {}:
        return None
    else:
        relevant_grades = midterm_grades(dictionary)
        name = [student for student in dictionary if dictionary.get(
            student)[2] == max(relevant_grades)]
        return name[0]


def longest_sequence(*args):
    """
    returns the number of consecutive terms
    :param args: list of all terms
    :return: (integer) number of consecutive numbers
    """
    unique_args = set(args)
    sorted_args = sorted(unique_args)
    count = 0
    temp_count = 0
    previous_number = 0
    for current_number in sorted_args:
        if sorted_args.index(current_number) == 0:
            temp_count = 1
        elif current_number - previous_number  == 1:
            temp_count += 1
        else:
            temp_count = 1
        previous_number = current_number
        if temp_count > count:
            count = temp_count
    return count

def encrypt(function):
    """
    Q3 A decorator to encrypt your strings
    :param function: function which uses a string as an input
    :return: decorator to encrypt string
    """

    def encrpyt_wrapper(*args):
        result = function(*args).lower().split()
        modified_phrase = [word.replace('e','').replace('s', 'sa') for word
                           in result]
        modified_phrase.reverse()
        return ' '.join(modified_phrase)
    return encrpyt_wrapper

def learn(file_name):
    """
    Q4 reads file and creates a dictionary of all the words after a word
    :param file_name: file to read
    :return: (dictionary) words preceding the word
    """
    with open(file_name,'r', encoding='UTF=8') as input_file:
        my_dict = {}
        previous_word = ''
        for line in input_file:
            words = line.rstrip().split()
            if words.__contains__('&'):
                words.remove('&')
            for word in words:
                word = word.lower().strip(string.punctuation)
                if previous_word in my_dict.keys():
                    my_dict[previous_word] = my_dict.get(previous_word)+[word]
                    if word not in my_dict.keys():
                        my_dict[word] = []
                else:
                    if previous_word == '':
                        pass
                    else:
                        my_dict[previous_word] = [word]
                previous_word = word
        return my_dict

def babble(file_name, length = 8):
    """
    Q5 random sentence generator
    :param file_name: file to learn words from
    :param length: length of sentence
    :return: (generator) sentence generator
    """
    dictionary = learn(file_name)
    sentence = (make_sentence(dictionary,length))
    return sentence

def make_sentence(dictionary,length):
    """
    generator function for babble
    :param dictionary: input dictionary
    :param length: how long the sentence should be
    :return: (string) new sentence
    """
    all_keys = list(dictionary)
    word = random.choice(all_keys)
    sentence = ''
    for x in range(0,length):
        sentence = sentence + word + ' '
        if dictionary.get(word) == []:
            word = random.choice(all_keys)
        else:
            word = random.choice(dictionary.get(word))
    sentence = sentence.strip()
    yield sentence



def main():

    #Q1
    empty_class = {}
    cs122 = {'Zoe': [90, 100, 75], 'Alex': [86, 90, 96],
             'Dan': [90, 60, 70], 'Anna': [60, 80, 100],
             'Ryan': [100, 95, 80], 'Bella': [79, 70, 99]}

    print(top_midterm(cs122))  # Anna
    print(top_midterm(empty_class))  # None
    print(cs122)  # cs 122 is unchanged

    #Q2
    print(longest_sequence(4, 10, 8, 3, 2, 11, 9, 40, 7, 7, 8, 4, 12))
    print(longest_sequence())
    print(longest_sequence(100, 202, 5, 2))
    print(longest_sequence(60))

    # Q3
    # You may use the main function to test your function definitions.
    @encrypt
    def greet(name):
        """
        Return a personalized hello message.
        :param name: (string)
        :return: (string)
        """
        return f'Hello {name}'

    @encrypt
    def repeat(phrase, n):
        """
        Repeat the specified string n times
        with a space character in between.
        :param phrase: (string)
        :param n: number of times the phrase will be repeated
        :return:
        """
        words = phrase.split()
        return ' '.join(n * words)

    print(greet('Spartans'))
    print(repeat("Special cases aren't special enough to break the rules",2))

    # Q4
    print(learn('spider.txt'))

    # Q5
    baby = babble('spider.txt',5)
    print(next(baby))



if __name__ == '__main__':
    main()
