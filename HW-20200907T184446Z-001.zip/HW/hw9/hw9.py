# ----------------------------------------------------------------------
# Name:        Hw9
# Purpose:     Build a program that systematically compiles COVID-19 information from multiple web pages and saves that data in a text file on the user's computer.
#
# Author:      Mark Mathew and Lovepreet Dhillon
# ----------------------------------------------------------------------
"""
Demonstrate using beautifulsoup (bs4) to help webcrawl and find articles
pertaining to COVID information.
"""
import requests
from bs4 import BeautifulSoup


def parse_site():
    """
    Method to parse a site for relevant data
    :return: textfile with country data printed
             prints country, population, cases, deaths, cases per 100k,
             deaths per 100k,and each country's first paragraph about the
             start of cases
    """

    # Allow the user to enter any country's name
    # user can enter country irrespective of case, will auto-uppercase
    # country name
    country = input("Enter country:").capitalize()
    # request from wiki page
    page = requests.get(
        'https://en.wikipedia.org/wiki'
        '/List_of_countries_and_dependencies_by_population')
    # web scraping using bs4
    soup = BeautifulSoup(page.content, 'html.parser')
    # provides demographics of country selected
    searchForLink = soup.find(title="Demographics of " + country)
    # will focus on data inside column of country chosen
    demographics_column = searchForLink.parent.parent
    # select the 'nth' child of the <td> tag
    populationStr = demographics_column.select("td:nth-of-type(3)")[0].text
    # remove the commas in population number
    population = int(populationStr.replace(',', ''))
    # extract data from requested wiki link
    page2 = requests.get(
        'https://en.wikipedia.org/wiki/2019%E2%80%9320_'
        'coronavirus_pandemic_by_country_and_territory')
    # web scraping using bs4
    soup2 = BeautifulSoup(page2.content, 'html.parser')
    # uses .find() to find where the text is found in table of countries
    countries_table = soup2.find(id="thetable").find(
        text=country).parent.parent.parent
    # get the link of data for the selected country from the table of
    # countries
    country_url = 'https://en.wikipedia.org' + \
                  countries_table.select("th:nth-of-type(2)")[0].select('a')[
                      0]['href']

    # gets the country url listed
    country_page = requests.get(country_url)
    # parsing through the web, scraping for data with bs4
    soup3 = BeautifulSoup(country_page.content, 'html.parser')
    country_p = soup3.find(id="mw-content-text").select('p:nth-of-type(3)')[
        0].text
    # counts the number of cases
    cases = int(
        countries_table.select("td:nth-of-type(1)")[0].text.replace(',', ''))
    # counts number of deaths
    deaths = int(
        countries_table.select("td:nth-of-type(2)")[0].text.replace(',', ''))
    # deaths per 100,000 people
    deaths_per_100k = round(deaths / population * 100000, 1)
    # cases per 100,000 people
    cases_per_100k = round(cases / population * 100000, 1)
    # convert any country entered to "countrysummary.txt"

    with open(country.lower() + "summary.txt", "w+", encoding="utf-8") as f:
        # First listed stat in textfile
        f.write("Country: " + country + "\n")
        # Second listed stat in textfile
        f.write("Population: " + populationStr + "\n")
        # Third listed stat in textfile
        f.write("Total Confirmed Cases: " + str(cases) + "\n")
        # Fourth listed stat in textfile
        f.write("Total Deaths: " + str(deaths) + "\n")
        # Fifth listed stat in textfile
        f.write("Cases per 100,000 people: " + str(cases_per_100k) + "\n")
        # Sixth listed stat in textfile
        f.write("Deaths per 100,000 people: " + str(deaths_per_100k) + "\n")
        f.write(country_p + "\n")
        f.close()
        # writes data as a .txt file to respective folder where this
        # file is saved.
        print("Your data has been written to: " + country.lower() +
              "summary.txt")

def main():
    parse_site()

if __name__ == "__main__":
    main()