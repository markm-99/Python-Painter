# ----------------------------------------------------------------------
# Name:        matchit
# Purpose:     Implement a single player matching game
#
# Author(s):
# ----------------------------------------------------------------------
"""
A single player matching game.

usage: matchit.py [-h] [-f] {blue,green,magenta} image_folder
positional arguments:
  {blue,green,magenta}  What color would you like for the player?
  image_folder          What folder contains the game images?

optional arguments:
  -h, --help            show this help message and exit
  -f, --fast            Fast or slow game?
"""
import tkinter
import os
import random
import argparse


class MatchGame(object):

    """
    GUI Game class for a matching game.

    Arguments:
    parent: the root window object
    player_color (string): the color to be used for the matched tiles
    folder (string) the folder containing the images for the game
    delay (integer) how many milliseconds to wait before flipping a tile

    Attributes:
    Please list ALL the instance variables here
    """

    # Add your class variables if needed here - square size, etc...)
    square_size = 100
    revealed_images = []

    def __init__(self, parent, player_color, folder, delay):
        """
        Initialize the concentration game
        :param parent: Parent tkinter interface
        :param player_color: color of matched tiles parsed
        :param folder: directory of images
        :param delay: speed of image disappearance
        """
        parent.title('Match it!')
        # Create the restart button widget
        self.restart_button = tkinter.Button(parent, text='RESTART', command
        = self.restart)
        # Create a canvas widget
        self.canvas = tkinter.Canvas(parent, width=400, height=400)
        for x in range(0, 400, 100):
            for y in range(0, 400, 100):
                self.canvas.create_rectangle(x, y, x + self.square_size,
                                             y + self.square_size,
                                             outline='black', fill="yellow")
        self.canvas.bind("<Button-1>", self.play)
        # Create a label widget for the score and end of game messages
        self.game_label = tkinter.Label(parent, text='')
        self.score_label = tkinter.Label(parent, text=f'Score: 100')
        self.tries_label = tkinter.Label(parent, text = '')
        # Create any additional instance variable you need for the game
        self.tries = 0
        self.matches = 0
        self.delay = delay
        self.color = player_color
        self.folder = folder
        self.images = []
        for file in os.listdir(folder):
            if file.endswith(".gif"):
                self.images.append(file)
        if len(self.images) > 8:
            self.images = self.images[0:8]
        self.images_dict = {}
        for image in self.images:
            self.images_dict[image] = tkinter.PhotoImage(file=folder+"/"+image)
        self.images = self.images + self.images
        random.shuffle(self.images)
        # take out the pass statement and enter your code
        self.restart_button.grid()
        self.canvas.grid()
        self.game_label.grid()
        self.score_label.grid()
        self.tries_label.grid()


    def restart(self):
        """
        This method is invoked when player clicks on the RESTART button.
        It shuffles and reassigns the images and resets the GUI and the
        score.
        :return: None
        """
        self.game_label.configure(text='')
        self.score_label.configure(text="Score: 100")
        self.tries_label.configure(text='')
        self.tries = 0
        self.matches = 0
        random.shuffle(self.images)
        for image in self.revealed_images:
            self.canvas.delete(image)
        for shape in self.canvas.find_all():
            self.canvas.itemconfigure(shape, fill='yellow')
        # take out the pass statement and enter your code

    def play(self, event):
        """
        This method is invoked when the user clicks on a square.
        It implements the basic controls of the game.
        :param event: event (Event object) describing the click event
        :return: None
        """
        # take out the pass statement and enter your code
        shape = self.canvas.find_closest(event.x, event.y)
        if shape[0] < 17 and len(self.revealed_images) < 2 and \
                self.canvas.itemcget(shape, 'fill') == 'yellow':
            self.canvas.itemconfigure(shape, tag="selected")
            image_id = self.canvas.create_image(self.canvas.coords(shape)[
                                                    0]+self.square_size/2,
                                                self.canvas.coords(shape)[
                                                    1]+self.square_size/2,
                                                image=self.images_dict[
                                                    self.images[shape[
                                                                    0]-1]],
                                                tag =self.images_dict[
                                                    self.images[shape[
                                                                    0]-1]])
            self.revealed_images.append(image_id)
        if len(self.revealed_images) == 2:
            self.tries += 1
            if self.tries > 13:
                score = 100 - ((self.tries - 13) * 10)
                self.score_label.configure(text=f'Score: {score}')
            if self.canvas.gettags(self.revealed_images[0]) == \
                    self.canvas.gettags(self.revealed_images[1]):
                for rect in self.canvas.find_withtag("selected"):
                    self.canvas.itemconfig(rect, fill=self.color, tag="")
                self.matches += 1
            if self.delay:
                    self.canvas.after(1000, self.update)
            else:
                    self.canvas.after(3000, self.update)
            if self.matches == 8:
                self.game_label.configure(text='Game over!')
                self.tries_label.configure(text = f'Number of tries: '
                f'{self.tries}')


    # Enter your additional method definitions below
    # Make sure they are indented inside the MatchGame class
    # Make sure you include docstrings for all the methods.
    def update(self):
        """
        updates the canvas after every match
        :return: None
        """
        for image in self.revealed_images:
            self.canvas.delete(image)
        self.revealed_images = []
        for rect in self.canvas.find_withtag("selected"):
            self.canvas.itemconfig(rect, tag="")

# Enter any function definitions here to get and validate the
# command line arguments.  Include docstrings.
def folder_type(folder):
    """
    Checks to see if folder contains at least 8 gif files
    :param folder: folder inputted
    :return: the valid directory
    """
    if os.path.exists(folder):
        image_check = []
        for file in os.listdir(folder):
            if file.endswith(".gif"):
                image_check.append(file)
        if len(image_check) < 8:
            raise argparse.ArgumentTypeError("must contain at least 8 gif "
                                           "images")
        else:
            return folder
    else:
        raise argparse.ArgumentTypeError(folder + 'is not a valid folder')


def get_arguments():
    """
    Parse and validate the command line arguments.
    :return: tuple containing color of matched tiles, image
        directory and game speed indicator
    """
    parser = argparse.ArgumentParser()

    parser.add_argument('color',
                        help='What color would you like for the player?',
                        choices=['blue', 'green', 'magenta'])
    parser.add_argument('image_folder',
                        help=' What folder contains the game images?',
                        type=folder_type)
    parser.add_argument('-f', '--fast',
                        help='Fast or slow game?',
                        action='store_true')

    arguments = parser.parse_args()
    color = arguments.color
    folder = arguments.image_folder
    delay = arguments.fast

    return color, folder, delay

def main():
    # Retrieve and validate the command line arguments using argparse
    player_color, folder, delay = get_arguments()
    # Instantiate a root window
    root = tkinter.Tk()
    # Instantiate a MatchGame object with the correct arguments
    MatchGame(root, player_color, folder, delay)
    # Enter the main event loop
    root.mainloop()
    # take out the pass statement and enter your code




if __name__ == '__main__':
    main()
    
