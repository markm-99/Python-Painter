dog_name = "Benny"
#f-string lets us do vairable replacement
print(f"My dog's name is {dog_name} and he smells like shit!")
