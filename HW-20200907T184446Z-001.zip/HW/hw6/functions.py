def sayHi(name):
    print(f"Hello {name}!")
sayHi("Julie")

def describe_yourself(name, age):
    print(f"My name is {name}. My age is {age}")

describe_yourself("Mark", 20)
