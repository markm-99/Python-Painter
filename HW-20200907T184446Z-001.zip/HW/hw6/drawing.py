import turtle
screen = turtle.Screen()
screen.bgcolor("red")
screen.title("Drawing lines for practice")

my_turtle = turtle.Turtle()
my_turtle.shape("turtle")
my_turtle.forward(100)

my_turtle.left(45)
my_turtle.penup()
my_turtle.forward(100)
my_turtle.pendown()
my_turtle.forward(100)
my_turtle.backward(100)

for x in range(0,8):
  my_turtle.forward(100)
  my_turtle.backward(100)
  my_turtle.right(45)

my_turtle.hideturtle()
turtle.done()
# next project for circle
screen = turtle.Screen()
screen.bgcolor("blue")
scren.title("Draw circles practice")

my_turtle = turtle.Turtle()
my_turtle.pensize(5)
my_turtle.begin_fill()


my_turtle.circle(100)
turtle.done()
