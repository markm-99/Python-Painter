# ----------------------------------------------------------------------
# Name:     Homework 6
# Purpose:  Implement a product class database
#
# Author:   Lovepreet Dhillon and Mark Mathew
# ----------------------------------------------------------------------

class Product:

    """
    Product representation
    Arguments:
    description (string): product description
    list_price (int): product price
    Attributes:
    description (string): Product's title
    list_price (float): Product's listed price
    stock (integer): Product's total stock
    id (string): Product's unique identifier
    sales (list): Product's up-to-date sales
    reviews (list): Product's up-to-date reviews
    """

    category = 'GN'
    next_serial_number = 1

    def __init__(self, description, list_price):
        self.description = description
        self.list_price = list_price
        self.stock = 0
        self.id = self.generate_product_id()
        self.sales = []
        self.reviews = []


    def restock(self, quantity):
        """
        Add stock quantity.
        :param quantity: (number) quantity to add.
        return: none
        """
        self.stock += quantity

    def review(self, stars, text):
        """
        Tracking the reviews.
        :param stars: (number) track the amount of stars a review has.
        :param text:(string) show the text of the review
        """
        self.reviews.append((text, stars))

    def sell(self, quantity, sale_price):
        """
        Tracking sold items.
        :param quantity: (number) amount of quantity that was sold.
        :param sale_price: (number) dollar amount at which item was
        sold.
        return: nothing
        """
        for i in range(quantity):
            if self.stock > 0:  # if there is something in stock
                self.sales.append(sale_price)
                self.stock -= 1

    # help
    @classmethod
    def generate_product_id(cls):
        """
        Generate Product ID
        return: (string) an id number for each individual product
        """
        id = cls.category + f"{cls.next_serial_number:06}"
        cls.next_serial_number += 1
        return id

    def __add__(self, other):
        return Bundle(self, other)

    def __str__(self):
        return f'{self.description}\nProduct ID: {self.id}\nList price: $' \
               f'{self.list_price:.2f}\nAvailable in stock: {self.stock}'


    @property
    def lowest_price(self):
        """
        finds and returns the lowest price sale
        :return: (integer) lowest priced sale
        """
        if len(self.sales) > 0:
            return min(self.sales)
        else:
            return None

    @property
    def average_rating(self):
        """
        gets the average rating of a product
        :return: (float) the average rating
        """
        if len(self.reviews) > 0:
            return sum(review[1] for review in self.reviews) / len(
                self.reviews)
        else:
            return None

    def __add__(self,other):
        return Bundle(self,other)

class VideoGame(Product):

    """
    Video Game product
    """

    category = "VG"
    next_serial_number = 1

class Book(Product):

    """
    Product that represents a book
    inherits from: Product

    Argument:
    book_title (string): Book's title
    boot_author (string): Book's Author
    book_pages (integer): Book's total number of pages
    book_price (float): Book's price

    Attributes:
    description (string): Product's title
    author (string): Product's author
    pages (integer): Product's total number of pages
    list_price (float): Product's listed price
    stock (integer): Product's total stock
    id (string): Product's unique identifier
    sales (list): Product's up-to-date sales
    reviews (list): Product's up-to-date reviews
    """

    category = 'BK'
    next_serial_number = 1

    def __init__(self,book_title,book_author,book_pages,book_price):
        self.description = book_title
        self.author = book_author
        self.pages = book_pages
        self.list_price = book_price
        self.stock = 0
        self.id = self.generate_product_id()
        self.sales = []
        self.reviews = []

    def __lt__(self, other):
        return self.pages < other.pages

    # no need to def greater than since python swaps less than for us

class Bundle(Product):

    """
    Product that represents a bundle of different products
    inherits from: Product
    """

    category = "BL"
    next_serial_number = 1
    bundle_discount = 20

    def __init__(self, *products):
        description = ""
        list_price = 0
        for product in products:
            description += product.description + " & "
            list_price += product.list_price
        self.description = description.rstrip('& ')
        self.list_price = list_price * (1 - self.bundle_discount/100)
        self.stock = 0
        self.id = self.generate_product_id()
        self.sales = []
        self.reviews = []


def main():

    # Part 1
    print("Part 1")
    sunglasses = Product("Vans Hip Cat Sunglasses", 14)
    print(Product.category)
    print(Product.next_serial_number)
    print(sunglasses.id)
    print(sunglasses.description)
    print(sunglasses.list_price)
    print(sunglasses.stock)
    print(sunglasses.reviews)
    print(sunglasses.sales)
    headphones = Product("Apple Airpods", 159)
    sunglasses.restock(20)
    headphones.restock(5)
    print(sunglasses)
    print(headphones)
    sunglasses.sell(3, 14)
    sunglasses.sell(1, 10)
    print(sunglasses.sales)
    headphones.sell(8, 140)  # There are only 5 available
    print(headphones.sales)
    print(sunglasses)
    print(headphones)
    sunglasses.restock(10)
    print(sunglasses)
    headphones.restock(20)
    print(headphones)
    sunglasses.review(5, "Great sunglasses! Love them.")
    sunglasses.review(3, "Glasses look good but they scratch easily")
    headphones.review(4, "Good but expensive")
    print(sunglasses.reviews)
    print(headphones.reviews)
    print(Product.category)
    print(Product.next_serial_number)

    # Part 2
    print("Part 2")
    print(sunglasses.lowest_price)
    print(sunglasses.average_rating)
    backpack = Product("Nike Explore", 60)
    print(backpack.average_rating)
    print(backpack.lowest_price)

    # Part 3
    print("Part 3")
    mario = VideoGame('Mario Tennis Aces', 50)
    mario.restock(10)
    mario.sell(3, 40)
    mario.sell(4, 35)
    print(mario)
    print(mario.lowest_price)
    mario.review(5, "Fun Game!")
    mario.review(3, "Too easy")
    mario.review(1, "Boring")
    print(mario.average_rating)
    lego = VideoGame('LEGO The Incredibles', 30)
    print(lego)
    lego.restock(5)
    lego.sell(10, 20)
    print(lego)
    print(lego.lowest_price)
    print(VideoGame.category)
    print(VideoGame.next_serial_number)

    # Part 4
    print("Part 4")
    book1 = Book("The Quick Python Book", "Naomi Ceder", 472, 39.99)
    print(book1.author)
    print(book1.pages)
    book1.restock(10)
    book1.sell(3, 30)
    book1.sell(1, 32)
    book1.review(5, "Excellent how to guide")
    print(book1)
    print(book1.average_rating)
    print(book1.lowest_price)
    book2 = Book("Learning Python", "Mark Lutz", 1648, 74.99)
    book1.restock(20)
    book1.sell(2, 50)
    print(book2)
    print(book1 > book2)
    print(book1 < book2)
    print(Book.category)
    print(Book.next_serial_number)

    # Part 5
    print("Part 5")
    bundle1 = Bundle(sunglasses, backpack, mario)
    print(bundle1)
    bundle1.restock(3)
    bundle1.sell(1, 90)
    print(bundle1)
    bundle1.sell(2, 95)
    print(bundle1)
    bundle1.restock(3)
    bundle1.sell(1, 90)
    print(bundle1)
    bundle1.sell(3, 95)
    print(bundle1)
    print(bundle1.lowest_price)
    bundle2 = Bundle(book1, book2)
    bundle2.restock(2)
    print(bundle2)
    print(Bundle.category)
    print(Bundle.next_serial_number)
    print(Bundle.bundle_discount)

    # Part 6
    print("Part 6")
    back_to_school_bundle = backpack + book1
    print(back_to_school_bundle)

    best_bundle = sunglasses + headphones + book1 + mario
    print(best_bundle)

if __name__ == '__main__':
    main()