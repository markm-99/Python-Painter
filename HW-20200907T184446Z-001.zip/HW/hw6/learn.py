def learn(num):
	"""This function returns the absolute
	value of the entered number"""

	if num >= 0:
		return num
	else:
		return -num

# Output: 2
print(learn(2))

# Output: 4
print(learn(-4))