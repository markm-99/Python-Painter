#access info in a specific order
numbers = [1,2,3,4,5]
pizza_toppings = ["cheese", "pepperoni"]
mixed_list = [1, "cheese", 2, "pepperoni"]
list_of_lists = [[1,2], [2,3]]

pizza_toppings.append("pineapple")
pizza_toppings.insert(0, "mushrooms")

print(pizza_toppings)

del pizza_toppings[0]
print(pizza_toppings)

pizza_toppings.pop()
print(pizza_toppings)

pizza_toppings.remove("cheese")
print(pizza_toppings)
