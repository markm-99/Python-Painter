# ----------------------------------------------------------------------
# Name:    homework4
# Purpose: Practice Dictionaries, Comprehensions & Generator Expressions
#
# Author(s):
# ----------------------------------------------------------------------
"""
Implement various functions with dictionaries and generator expressions.

Q1: top_students
Q2: final_grade
Q3: boost_grade
Q4: word_lengths
Q5: geometric_sum
"""
import string

# Enter your 5 function definitions here
def top_students(dictionary, size = 3):
    """
    Q1 Function to return a list of the top students in a dictionary
    :param dictionary: input dictionary of students
    :param size: input size of returned list
    :return: (list) of top students
    """
    return [student for student in sorted(dictionary,key=dictionary.get,
                                          reverse=True) if sorted(
        dictionary, key=dictionary.get, reverse=True).index(student) < size]

def final_grade(dictionary, extra_points = 1):
    """
    Q2 Updates the grades of students
    :param dictionary: input dictionary of students
    :param extra_points: amount of extra points
    :return: updated dictionary of students grades
    """
    return {student: dictionary[student]+extra_points for student in dictionary}

def boost_grade(points, grades):
    """
    Q3 Boosts the grades of student with above average participation
    :param points: dictionary of students and their iClicker points
    :param grades: dictionary of students and their exam scores
    :return: (dictionary) students grades after extra credit
    """
    if len(points) > 0:
        average = sum([*points.values()]) / len([*points.values()])
        students_to_be_boosted = {
        student: 1 if points[student] > average else 0
        for student in points}
        boosted_grades = {student: grades[student] + students_to_be_boosted[
            student] if student in grades else students_to_be_boosted[
            student] for student in students_to_be_boosted}
        combined_grades = {**grades, **boosted_grades}
        return combined_grades
    else:
        return grades

def word_lengths(phrase):
    """
    turns the phrase into a dictionary
    :param string: the phrase being used
    :return: a dictionary with the value being the length of the word
    """
    return {word: len(word) for word in phrase.strip(
        string.punctuation).replace(',', '').lower().split()}

def geometric_sum(number):
    """
    generate a sum of a geometric series when queried
    :param number: number of terms to sum
    :return: (number) geometric series sum
    """
    return sum(1/2**n for n in range(1,number+1))


def main():
    # You may use the main function to test your function definitions.
    empty_class = {}
    cs122 = {'Zoe': 90, 'Alex': 93, 'Dan': 79, 'Anna': 100}

    print(top_students(cs122, 2))  # ['Anna', 'Alex']
    print(top_students(cs122))  # ['Anna', 'Alex', 'Zoe']
    print(top_students(cs122, 10))  # ['Anna', 'Alex', 'Zoe', 'Dan']
    print(cs122)  # {'Zoe': 90, 'Alex': 93, 'Dan': 79, 'Anna': 100}

    print(top_students(empty_class, 6))  # []

    empty_class = {}
    cs122 = {'Zoe': 90, 'Alex': 93, 'Dan': 79, 'Anna': 100}

    print(final_grade(cs122))  # {'Zoe':91, 'Alex': 94, 'Dan':80, 'Anna':101}
    print(final_grade(cs122, 2))  # {'Zoe':92, 'Alex': 95, 'Dan':81,'Anna':102}
    print(cs122)  # {'Zoe':90, 'Alex': 93, 'Dan':79, 'Anna':100}
    print(final_grade(empty_class, 5))  # {}

    iclicker = {'Zoe': 46, 'Alex': 121, 'Ryan': 100, 'Anna': 110,
                'Bryan': 2, 'Andrea': 110}
    exam = {'Dan': 89, 'Ryan': 89, 'Alex': 95, 'Anna': 64,
            'Bryan': 95, 'Andrea': 86}

    print(boost_grade(iclicker, exam))
    print(boost_grade({}, exam))
    print(boost_grade(iclicker, {}))
    print(boost_grade({}, {}))

    phrase = '''Simple is better than     complex, and flat 
                 IS BETTER than nested!?!'''

    print(word_lengths(''))
    print(word_lengths(phrase))

    print(geometric_sum(-5))  # 0
    print(geometric_sum(0))  # 0
    print(geometric_sum(1))  # 0.5
    print(geometric_sum(2))  # 0.75
    print(geometric_sum(3))  # 0.875
    print(geometric_sum(4))  # 0.9375
    print(geometric_sum(30))  # 0.9999999990686774

if __name__ == '__main__':
    main()
