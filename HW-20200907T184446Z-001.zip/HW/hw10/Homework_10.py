# ----------------------------------------------------------------------
# Name:     Homework 10
# Purpose:  Answer Questions about a dataset
#
# Author:   Lovepreet Dhillon and Mark Mathew
# ----------------------------------------------------------------------

import pandas as pd
import numpy as np

def q1(dataframe):
    """
    Returns how many cars are made by the division Audi
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: integer representing number of cars made
    """
    return len(dataframe.loc[dataframe["Division"] == 'Audi'])

def q2(dataframe):
    """
    Return how many unique divisions there are for the maunfacturer
    General Motors
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: integers representing number of unique divisions
    """
    return len(dataframe.loc[dataframe['Mfr Name'] == "General Motors"]
               ['Division'].unique())

def q3(dataframe):
    """
    Return the most frequent producer of guzzlers
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: string of the most frequent producer of guzzlers
    """
    df_guzzlers = dataframe.loc[dataframe["Guzzler?"] == 'G']
    return df_guzzlers["Mfr Name"].mode().iloc[0]

def q4(dataframe):
    """
    Return the highest Comb FE (Guide) - Conventional Fuel value
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: float of the highest value under
              Comb FE (Guide) - Conventional Fuel
    """
    return dataframe["Comb FE (Guide) - Conventional Fuel"].max()

def q5(dataframe):
    """
    Return the division and carline of the lowest combined fe
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: tuple of division and carline of applicable value
    """
    min_fuel = dataframe["Comb FE (Guide) - Conventional Fuel"].min()
    rows = dataframe.loc[dataframe["Comb FE (Guide) - Conventional Fuel"]
                        == min_fuel]
    return (rows["Division"][0], rows.index[0])


def q6(dataframe):
    """
    Find the average combined conventional fuel cost
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: float containing the average combined fuel of conventional fuel
    """
    all_wheel = dataframe.loc[dataframe["Drive Desc"] == 'All Wheel Drive']
    return all_wheel['Comb FE (Guide) - Conventional Fuel'].mean()

def q7(dataframe):
    """
    Find the car line with the greatest difference in highway and city
    conventional fuel costs
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: string with the carline with the greatest difference
    """
    return (dataframe["Hwy FE (Guide) - Conventional Fuel"] -
            dataframe["City FE (Guide) - Conventional Fuel"]).idxmax()

def q8(dataframe):
    """
    Find average annual fuel cost of supercharged vehicles
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: float with the average fuel cost of only supercharged cars
    """
    supercharged = dataframe.loc[dataframe['Air Aspiration Method Desc'] ==
                                 'Supercharged']
    return supercharged['Annual Fuel1 Cost - Conventional Fuel'].mean()

def q9(dataframe):
    """
    Find the SUV with the lowest annual fuel cost
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: string with the SUV with the lowest annual fuel cost
    """
    suv = dataframe.loc[dataframe['Carline Class Desc'].str.contains('SUV',
                                                                     na=False)]
    return suv['Annual Fuel1 Cost - Conventional Fuel'].idxmin()

def q10(dataframe):
    """
    Find the average annual fuel costs by division
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: Pandas Series with the index as car division and one column
    with average annual fuel costs
    """
    average_annual_fuel = dataframe.groupby('Division').agg({
        'Annual Fuel1 Cost - Conventional Fuel' : (np.mean)})
    return pd.Series(average_annual_fuel['Annual Fuel1 Cost - Conventional '
                                         'Fuel'],
                     index=average_annual_fuel.index)

def q11_lovepreet(dataframe):
    """
    Not much of a car person but my one requirement is a lot of leg space
    in any future car i'll drive since i'm 6 ft 5in and in my experience BMW's
    have just that, and aim for low annual fuel costs to save commute costs
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: string with my target car line
    """
    bmw = dataframe.loc[dataframe['Division'] == 'BMW']
    return "BMW " + str(bmw['Annual Fuel1 Cost - Conventional Fuel'].idxmax())

def q11_mark(dataframe):
    """
    I love the luxury feel and sleek look of a Ferrari;
    having the doors go up is a very cool feature of a car.
    More cylinders would allow for more engine power and allow me to
    achieve higher speeds on a racetrack than traditional cars.
    :param dataframe: Pandas dataframe representing the 2020 FE Guide
    :return: string with my target car line
    """
    ferrari = dataframe.loc[dataframe['Division'] == 'Ferrari North America, Inc.']
    return "Ferrari " + str(ferrari['# Cyl'].idxmax())

def main():
    #ignore first column
    df_fe_guide = pd.read_csv('2020 FE Guide.csv', index_col='Carline',
                              usecols = range(1,449))
    print("Q1: " + str(q1(df_fe_guide)))
    print("Q2: " + str(q2(df_fe_guide)))
    print("Q3: " + q3(df_fe_guide))
    print("Q4: " + str(q4(df_fe_guide)))
    print("Q5: " + str(q5(df_fe_guide)))
    print("Q6: " + str(q6(df_fe_guide)))
    print("Q7: " + q7(df_fe_guide))
    print("Q8: " + str(q8(df_fe_guide)))
    print("Q9: " + q9(df_fe_guide))
    print("Q10: " + str(q10(df_fe_guide)))
    print("Q11 Preet: " + q11_lovepreet(df_fe_guide))
    print("Q11 Mark: " + q11_mark(df_fe_guide))

if __name__ == '__main__':
    main()
