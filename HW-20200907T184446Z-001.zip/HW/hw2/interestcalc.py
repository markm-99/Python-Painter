# ----------------------------------------------------------------------
# Name:        interestcal
# Purpose:     CS 122 Homework 2
#
# Author(s): Lovepreet Dhillon & Mark Mathew
# ----------------------------------------------------------------------
"""
Simple interest calculator

Prompts the user for a principal amount and interest rate before
calculating the interest value and printing to console
"""
# Enter your constant assignments here
MAX_PRINCIPAL = 1000000
MAX_INTEREST = 20

# Enter your function definitions here
# You must have at least 3 non-trivial functions other than main.
def get_principal():
    """
    Get the starting principal
    :return: (number) valid starting principal
    """
    success = False
    while not success:
        principal = float(input('Please enter principal amount: $'))
        if principal >= 0 and principal <= MAX_PRINCIPAL:
            success = True
        else:
            print('Invalid amount. Principal must be between $0 and '
                  '$1,000,000.')
    return principal

def get_interest_rate():
    """
    Get the interest rate
    :return: (number) valid interest input
    """
    success = False
    while not success:
        interest = float(input('Please enter interest rate: %'))
        if interest >= 0 and interest <= MAX_INTEREST:
            success = True
        else:
            print('Invalid rate. Interest rate must be between 0% and '
                  '20%.')
    return interest

def calculate_interest(principal,interest):
    """
    Prints the accrued interest every decade for five decades
    :param principal: (number) starting principal
    :param interest: (number) interest rate
    :return:
    """
    for year in range(10,60,10):
        accrued_interest = (principal * pow(1.0 + (interest/100),year))
        formatted_interest = f'${accrued_interest:,.2f}'
        print(f'Accrued amount after {year} years:{formatted_interest:>18}')



def main():
    # The main function must be non-trivial
    # Please enter your code and take out the pass statement below.
    principal = get_principal()
    interest = get_interest_rate()
    calculate_interest(principal,interest)

if __name__ == "__main__":
    main()
